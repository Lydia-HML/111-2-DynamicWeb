$(document).on("mobileinit", function() {
  $.mobile.defaultPageTransition = "flip"; //頁面切換方式
  $.mobile.popup.prototype.options.overlayTheme = "b"; //以深色覆蓋背景
});
$(document).on("pagecreate",function(){
    $(window).on("orientationchange",function(){
    alert("行動裝置方向已改變");
    });                   
});